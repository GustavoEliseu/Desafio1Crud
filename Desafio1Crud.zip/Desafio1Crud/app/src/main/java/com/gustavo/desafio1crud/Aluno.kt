package com.gustavo.desafio1crud

import java.sql.Date

class Aluno(var nome: String,var data:Date) {}