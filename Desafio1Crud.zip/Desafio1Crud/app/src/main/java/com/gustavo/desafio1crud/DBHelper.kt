package com.gustavo.desafio1crud

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper (context: Context, factory: SQLiteDatabase.CursorFactory?) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    private val CREATE_TABLE_ALUNOS =
        "CREATE TABLE "+TABLE_ALUNOS+" ("+COLUNA_MATRICULA+" INTEGER PRIMARY KEY AUTOINCREMENT, "+COLUNA_NOME+" TEXT NOT NULL, "+COLUNA_DATA+" TEXT);"
    private val CREATE_TABLE_NOTAS =
        "CREATE TABLE "+TABLE_NOTAS+" ("+COLUNA_MATRICULA+" INTEGER , "+COLUNA_NOTA+" INTEGER CHECK ("+COLUNA_NOTA+" > 0 AND "+COLUNA_NOTA+" <11), "+COLUNA_MATERIA+" TEXT NOT NULL);"

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(CREATE_TABLE_ALUNOS)
        db.execSQL(CREATE_TABLE_NOTAS)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ALUNOS)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTAS)
        onCreate(db)
    }

    fun addAluno(aluno: Aluno) {
        val values = ContentValues()
        values.put(COLUNA_NOME, aluno.nome)
        values.put(COLUNA_DATA, aluno.data.toString())
        val db = this.writableDatabase
        db.insert(TABLE_ALUNOS, null, values)
        db.close()
    }

    fun addNota(nota: Nota) {
        val values = ContentValues()
        values.put(COLUNA_MATRICULA,nota.matricula)
        values.put(COLUNA_NOTA, nota.valor)
        values.put(COLUNA_MATERIA, nota.materia)
        val db = this.writableDatabase
        db.insert(TABLE_NOTAS, null, values)
        db.close()
    }

    fun getAllAlunos(): Cursor? {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_ALUNOS", null)
    }

    fun getAllNota(): Cursor? {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NOTAS", null)
    }


    companion object {

        private val DATABASE_NAME = "Crud.db"
        private val COLUNA_MATRICULA ="MATRICULA"
        private val COLUNA_NOME= "NOME"
        private val COLUNA_DATA= "DATA"
        private val COLUNA_MATERIA= "MATERIA"
        private val COLUNA_NOTA = "NOTA"
        private val TABLE_ALUNOS = "ALUNOS"
        private val TABLE_NOTAS = "NOTAS"
        private val DATABASE_VERSION = 1
    }
}