package com.gustavo.desafio1crud

class Nota(val matricula: Int, aluno: Aluno,val materia: String,var valor: Int) {}